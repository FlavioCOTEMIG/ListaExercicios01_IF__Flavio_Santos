﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExerxicios_06_a_08_FlavioSantos_
{
    public partial class Frm07 : Form
    {
        public Frm07()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            string Genero = txtGenero.Text;
            float Peso = float.Parse(txtPeso.Text);
            float Altura = float.Parse(txtAltura.Text);
            float result;
            switch (Genero)
            {
                case "M":
                    result = (Peso * Altura)- 58;
                    MessageBox.Show("Resultado: " + result + " (Homem)");
                    break;

                case "F":
                    result = (float)((Peso * Altura) - 44.7);
                    MessageBox.Show("Resultado: " + result + " (Mulher)");
                    break;

                case "m":
                    result = (Peso * Altura) - 58;
                    MessageBox.Show("Resultado: " + result + " (Homem)");
                    break;

                case "f":
                    result = (float)((Peso * Altura) - 44.7);
                    MessageBox.Show("Resultado: " + result + " (Mulher)");
                    break;

                default:
                    MessageBox.Show("Valor Invalido");
                    break;

            }
        }

        private void exibirFrm06_Click(object sender, EventArgs e)
        {
            Frm06 frm06 = new Frm06();
            this.Hide();
            frm06.ShowDialog();
        }

        private void exibirFrm07_Click(object sender, EventArgs e)
        {
            Frm07 frm07 = new Frm07();
            this.Hide();
            frm07.ShowDialog();
        }

        private void exibirFrm08_Click(object sender, EventArgs e)
        {
            Frm08 frm08 = new Frm08();
            this.Hide();
            frm08.ShowDialog();
        }
    }
}
