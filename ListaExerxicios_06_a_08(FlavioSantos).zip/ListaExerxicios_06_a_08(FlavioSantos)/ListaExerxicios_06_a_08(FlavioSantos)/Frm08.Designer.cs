﻿namespace ListaExerxicios_06_a_08_FlavioSantos_
{
    partial class Frm08
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm06 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm07 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm08 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnResult = new System.Windows.Forms.Button();
            this.txtGenero = new System.Windows.Forms.TextBox();
            this.lblGenero = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirFrm06,
            this.exibirFrm07,
            this.exibirFrm08});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirFrm06
            // 
            this.exibirFrm06.Name = "exibirFrm06";
            this.exibirFrm06.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm06.Text = "Questão 6";
            this.exibirFrm06.Click += new System.EventHandler(this.exibirFrm06_Click);
            // 
            // exibirFrm07
            // 
            this.exibirFrm07.Name = "exibirFrm07";
            this.exibirFrm07.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm07.Text = "Questão 7";
            this.exibirFrm07.Click += new System.EventHandler(this.exibirFrm07_Click);
            // 
            // exibirFrm08
            // 
            this.exibirFrm08.Name = "exibirFrm08";
            this.exibirFrm08.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm08.Text = "Questão 8";
            this.exibirFrm08.Click += new System.EventHandler(this.exibirFrm08_Click);
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResult.Location = new System.Drawing.Point(587, 228);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(150, 93);
            this.btnResult.TabIndex = 15;
            this.btnResult.Text = "Resultado";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // txtGenero
            // 
            this.txtGenero.Location = new System.Drawing.Point(82, 268);
            this.txtGenero.Name = "txtGenero";
            this.txtGenero.Size = new System.Drawing.Size(100, 20);
            this.txtGenero.TabIndex = 14;
            // 
            // lblGenero
            // 
            this.lblGenero.AutoSize = true;
            this.lblGenero.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenero.Location = new System.Drawing.Point(77, 240);
            this.lblGenero.Name = "lblGenero";
            this.lblGenero.Size = new System.Drawing.Size(156, 25);
            this.lblGenero.TabIndex = 13;
            this.lblGenero.Text = "Sexo (M ou F):";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(315, 96);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(169, 36);
            this.lblTitulo.TabIndex = 12;
            this.lblTitulo.Text = "QUESTÃO 8";
            // 
            // Frm08
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumAquamarine;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.txtGenero);
            this.Controls.Add(this.lblGenero);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Frm08";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm08";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm06;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm07;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm08;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.TextBox txtGenero;
        private System.Windows.Forms.Label lblGenero;
        private System.Windows.Forms.Label lblTitulo;
    }
}