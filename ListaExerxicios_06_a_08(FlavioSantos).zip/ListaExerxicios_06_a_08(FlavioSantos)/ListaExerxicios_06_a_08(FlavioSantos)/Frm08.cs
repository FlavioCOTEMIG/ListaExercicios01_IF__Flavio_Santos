﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExerxicios_06_a_08_FlavioSantos_
{
    public partial class Frm08 : Form
    {
        public Frm08()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            string Genero = txtGenero.Text;
            switch (Genero)
            {
                case "M":
                    MessageBox.Show("Sexo inválido pois é um projeto de mulheres");
                    break;

                case "F":
                    MessageBox.Show("Sexo feminino");
                    break;

                case "m":
                    MessageBox.Show("Sexo inválido pois é um projeto de mulheres");
                    break;

                case "f":
                    MessageBox.Show("Sexo feminino");
                    break;

                default:
                    MessageBox.Show("Valor Invalido");
                    break;

            }
        }

        private void exibirFrm06_Click(object sender, EventArgs e)
        {
            Frm06 frm06 = new Frm06();
            this.Hide();
            frm06.ShowDialog();
        }

        private void exibirFrm07_Click(object sender, EventArgs e)
        {
            Frm07 frm07 = new Frm07();
            this.Hide();
            frm07.ShowDialog();
        }

        private void exibirFrm08_Click(object sender, EventArgs e)
        {
            Frm08 frm08 = new Frm08();
            this.Hide();
            frm08.ShowDialog();
        }
    }
}
