﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExerxicios_06_a_08_FlavioSantos_
{
    public partial class Frm06 : Form
    {
        public Frm06()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            string Lados = txtNdLados.Text;
            switch (Lados)
            {
                case "3":
                    MessageBox.Show("Triangulo");
                    break;

                case "4":
                    MessageBox.Show("Quadrado");
                    break;

                default:
                    MessageBox.Show("Valor Invalido");
                    break;
            }
        }

        private void exibirFrm06_Click(object sender, EventArgs e)
        {
            Frm06 frm06 = new Frm06();
            this.Hide();
            frm06.ShowDialog();
        }

        private void exibirFrm07_Click(object sender, EventArgs e)
        {
            Frm07 frm07 = new Frm07();
            this.Hide();
            frm07.ShowDialog();
        }

        private void exibirFrm08_Click(object sender, EventArgs e)
        {
            Frm08 frm08 = new Frm08();
            this.Hide();
            frm08.ShowDialog();
        }
    }
}
