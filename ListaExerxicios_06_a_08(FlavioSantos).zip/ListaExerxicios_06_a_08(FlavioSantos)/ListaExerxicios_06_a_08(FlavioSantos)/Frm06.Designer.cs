﻿namespace ListaExerxicios_06_a_08_FlavioSantos_
{
    partial class Frm06
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblNdLados = new System.Windows.Forms.Label();
            this.txtNdLados = new System.Windows.Forms.TextBox();
            this.btnResult = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm06 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm07 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm08 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(295, 117);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(169, 36);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "QUESTÃO 6";
            // 
            // lblNdLados
            // 
            this.lblNdLados.AutoSize = true;
            this.lblNdLados.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNdLados.Location = new System.Drawing.Point(42, 270);
            this.lblNdLados.Name = "lblNdLados";
            this.lblNdLados.Size = new System.Drawing.Size(214, 25);
            this.lblNdLados.TabIndex = 1;
            this.lblNdLados.Text = "Nº de lados (3 ou4):";
            // 
            // txtNdLados
            // 
            this.txtNdLados.Location = new System.Drawing.Point(47, 298);
            this.txtNdLados.Name = "txtNdLados";
            this.txtNdLados.Size = new System.Drawing.Size(100, 20);
            this.txtNdLados.TabIndex = 2;
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResult.Location = new System.Drawing.Point(578, 270);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(150, 93);
            this.btnResult.TabIndex = 3;
            this.btnResult.Text = "Resultado";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirFrm06,
            this.exibirFrm07,
            this.exibirFrm08});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirFrm06
            // 
            this.exibirFrm06.Name = "exibirFrm06";
            this.exibirFrm06.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm06.Text = "Questão 6";
            this.exibirFrm06.Click += new System.EventHandler(this.exibirFrm06_Click);
            // 
            // exibirFrm07
            // 
            this.exibirFrm07.Name = "exibirFrm07";
            this.exibirFrm07.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm07.Text = "Questão 7";
            this.exibirFrm07.Click += new System.EventHandler(this.exibirFrm07_Click);
            // 
            // exibirFrm08
            // 
            this.exibirFrm08.Name = "exibirFrm08";
            this.exibirFrm08.Size = new System.Drawing.Size(180, 22);
            this.exibirFrm08.Text = "Questão 8";
            this.exibirFrm08.Click += new System.EventHandler(this.exibirFrm08_Click);
            // 
            // Frm06
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.txtNdLados);
            this.Controls.Add(this.lblNdLados);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm06";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm06";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblNdLados;
        private System.Windows.Forms.TextBox txtNdLados;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm06;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm07;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm08;
    }
}

